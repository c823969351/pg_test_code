import test_M695_1
import test_M695_2

if __name__ == '__main__':
    a= 'asdasdas'
    b = a[0:3]
    print(b)
import time
import pytest
import RS232


com = "COM21"    

g_pg = RS232.Communication(com, 115200, 15)

logfile = None
logfilename = ""

DELAY = 1

csv_file = None

def print_log(*args):
    strTime = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    print( strTime + ": ", end="")
    print(args)
    global logfile
    global logfilename
    if logfile == None:
        logfilename = time.strftime('%Y_%m_%d_%H_%M_%S', time.localtime(time.time())) +".log"
        logfile = open(logfilename, "wt")

    logfile.write( strTime + ": ")
    logfile.write(str(args) + '\n')
    logfile.flush()

    global csv_file
    if csv_file == None:
        csv_file = open(logfilename + ".csv", "wt")
def close():
    g_pg.Close_Engine()

class Test_01:
    def test_POWER_ON(self):
        data = (0xAA,0x01,0xC3,0x33,0x00,0x00,0x55) #开电
        g_pg.Send_data(data)
        time.sleep(4)
        strRet = g_pg.Read_Line()
        print_log("Recv:", strRet)
        strRet = strRet.split('\r')
        assert strRet[0] == "Display_on"

    def test_Show_VOLT(self):
        data = (0xAA,0x01,0xC3,0x55,0x00,0x00,0x55) #volt
        g_pg.Send_data(data)
        time.sleep(1)

        strRet = g_pg.Read_Line()
        strRet += g_pg.Read_Line()
        strRet += g_pg.Read_Line()
        strRet += g_pg.Read_Line()
        strRet += g_pg.Read_Line()
        print_log("Recv:", strRet)
        strRet = strRet.split('\r')
        strRet[0] = strRet[0][0:3]
        assert strRet[0] == 'LCD'
        

    def test_Sleep_IN(self):
        data = (0xAA,0x01,0xC3,0x44,0x00,0x00,0x55) #sleep in-1
        g_pg.Send_data(data)
        strRet = g_pg.Read_Line()
        strRet += g_pg.Read_Line()
        strRet += g_pg.Read_Line()
        strRet += g_pg.Read_Line()
        strRet += g_pg.Read_Line()
        print_log("Recv:", strRet)
        strRet = strRet.split('\r')
        time.sleep(3)
        assert strRet[0] == 'Sleep_in'

    def test_Sleep_OUT(self):
        data = (0xAA,0x01,0xC3,0x88,0x00,0x00,0x55) #sleep out-1
        g_pg.Send_data(data)
        strRet = g_pg.Read_Line()
        print_log("Recv:", strRet)
        strRet = strRet.split('\r')
        time.sleep(3)
        assert strRet[0] == 'Sleep_out'


    @pytest.mark.parametrize('num', [0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08])
    def test_SHOW_PATTERN(self,num):#切图-1
        data = (0xAA,0x01,0xC3,num,0x00,0x00,0x55) 
        g_pg.Send_data(data)
        time.sleep(2)
        strRet = g_pg.Read_Line()
        print_log("Recv:", strRet)
        strRet = strRet.split('\r')
        frame = 'frame='+str(num)
        assert strRet[0] == frame

    @pytest.mark.parametrize('num', [0x02,0x08])
    def test_SHOW_PATTERN_u(self,num):#切图-1
        data = (0xAA,0x01,0xC3,num,0x00,0x00,0x55) 
        g_pg.Send_data(data)
        time.sleep(2)
        strRet = g_pg.Read_Line()
        print_log("Recv:", strRet)
        strRet = strRet.split('\r')
        frame = 'frame='+str(num)
        assert strRet[0] == frame
    
    def test_Sleep_IN_2(self):
        data = (0xAA,0x01,0xC3,0x44,0x00,0x00,0x55) #sleep in-1
        g_pg.Send_data(data)
        strRet = g_pg.Read_Line()
        strRet += g_pg.Read_Line()
        strRet += g_pg.Read_Line()
        strRet += g_pg.Read_Line()
        strRet += g_pg.Read_Line()
        print_log("Recv:", strRet)
        strRet = strRet.split('\r')
        time.sleep(3)
        assert strRet[0] == 'Sleep_in'

    def test_Sleep_OUT_2(self):
        data = (0xAA,0x01,0xC3,0x88,0x00,0x00,0x55) #sleep out-1
        g_pg.Send_data(data)
        strRet = g_pg.Read_Line()
        print_log("Recv:", strRet)
        time.sleep(0.5)
        strRet = strRet.split('\r')
        time.sleep(3)
        assert strRet[0] == 'Sleep_out'

    '''def test_READ_SN():
        data = (0xAA,0x01,0xC3,0xD2,0x00,0x01,0x55) 
        g_pg.Send_data(data)'''
        
    def test_POWER_OFF(self):#Display_off-1
        data = (0xAA,0x01,0xC3,0x66,0x00,0x00,0x55) #关电
        g_pg.Send_data(data)
        strRet = g_pg.Read_Line()
        print_log("Recv:", strRet)
        strRet = strRet.split('\r')
        time.sleep(2)
        assert strRet[0] == 'Display_off'
        #close()

def delay_time(time_s):
    time.sleep(time_s)

def run():
    pytest.main(["-s", "test_M695_2.py"])
    
if __name__ == "__main__":
    '''pg.open()
    print(pg.query('*IDN?'))
    pg.powerOff('ALL')
    pg.close'''
    pytest.main(["-s", "test_M695_2.py"])
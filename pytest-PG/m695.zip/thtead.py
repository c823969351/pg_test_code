import threading
import time
import os
import test_M695_1
import test_M695_2

if __name__ == '__main__':
    fun1 = test_M695_1.run()
    fun2 = test_M695_2.run()
    
    sing_thread = threading.Thread(target=fun1)
    song_thread = threading.Thread(target=fun2)

    sing_thread.start()
    song_thread.start()